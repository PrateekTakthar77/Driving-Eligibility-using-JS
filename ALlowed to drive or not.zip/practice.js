let age = 16

if (age >= 18){
    console.log("you are allowed to drive")
}else
    console.log("you are not allowed to drive because you are under 18")